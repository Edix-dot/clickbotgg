Hello !!!!!, 

How its works?????

you have to get you api_id and api_hash from https://my.telegram.org here!

Basically it scrapes member from group where the logined id is admin and it creates a .csv file.
And the adder reads .csv file and add member to the target group.

